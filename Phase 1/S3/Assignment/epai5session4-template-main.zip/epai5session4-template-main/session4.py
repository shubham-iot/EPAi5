import random
from decimal import *

class Qualean:
  '''
  Yous description
  '''
  def __init__(self):
    pass
  
  # defining object representation
  def __repr__(self):
    return 'Proper text representing the class'
  
  # your other functions
